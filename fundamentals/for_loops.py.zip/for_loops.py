# for i in range(0,151):
#     print (i)

# for i in range(5,100,5):
#     if i%5 == 0:
#         print ("coding")

# for i in range(5,100,5):
#     if i%10 == 0:
#         print ("coding dojo")

# for i in range (2018,0,-4):
#     print(i)

# mult = 3
# for i in range(2,10):
#     if i % mult ==0:
#         print (i)
